﻿# --- Importações de bibliotecas necessárias ---
import xmlrpc.client  # Para comunicação com o rastreador (tracker) via XML-RPC.
import socket         # Para comunicação de rede (sockets) entre os pares.
import threading      # Para executar tarefas concorrentes (servidor e cliente).
import time           # Para pausas e medição de tempo.
import os             # Para operações com o sistema de arquivos (criar, ler, escrever).
import random         # Para selecionar pares aleatoriamente.
from collections import defaultdict # Para agrupar pares que possuem um mesmo pedaço do arquivo.
from concurrent.futures import ThreadPoolExecutor # Para gerenciar um pool de threads para downloads e uploads.

# --- Configurações Globais do Cliente P2P ---
URL_RASTREADOR = "http://localhost:8000"       # Endereço do servidor rastreador.
NOME_ARQUIVO = "ubuntu-teste.iso"              # Nome do arquivo a ser compartilhado.
TAMANHO_ARQUIVO_MB = 500                       # Tamanho total do arquivo em Megabytes.
TAMANHO_PEDACO = 1024 * 1024                   # Tamanho de cada pedaço do arquivo (1 MB).
TOTAL_PEDACOS = TAMANHO_ARQUIVO_MB             # Número total de pedaços do arquivo.

# --- Configurações de Performance Adaptativa ---
# Estes valores controlam como o número de downloads simultâneos se ajusta dinamicamente.
BASE_DOWNLOADS_SIMULTANEOS = 5   # Número mínimo de downloads que o par tentará fazer ao mesmo tempo.
INCREMENTO_POR_SEED = 5          # Aumento no número de downloads para cada seeder (semeador) na rede.
INCREMENTO_POR_PEER = 2          # Aumento no número de downloads para cada peer (par) na rede.
MAX_CONEXOES_SERVIDOR = 50       # Número máximo de conexões que o par aceitará como servidor.
INTERVALO_ATUALIZACAO = 1        # Intervalo em segundos entre os ciclos de atualização de status do download.
TIMEOUT_CONEXAO = 10             # Tempo máximo em segundos para esperar por uma resposta de outro par.
BUFFER_SIZE = 64 * 1024          # Tamanho do buffer (64 KB) para receber dados de rede, otimizando a transferência.

class Par:
    """
    Representa um nó (peer) na rede P2P. Cada par pode atuar como cliente (baixando pedaços)
    e como servidor (enviando pedaços que já possui).
    """
    def __init__(self, host_servidor, porta_servidor, eh_semeador=False):
        # --- Inicialização das propriedades do Par ---
        self.host_servidor = host_servidor
        self.porta_servidor = porta_servidor
        self.id_par = f"{host_servidor}:{porta_servidor}"  # Identificador único do par na rede.
        self.rastreador = xmlrpc.client.ServerProxy(URL_RASTREADOR) # Objeto para se comunicar com o rastreador.

        self.eh_semeador_inicial = eh_semeador  # Flag que indica se este par começa com o arquivo completo.
        self.meus_pedacos = set()               # Conjunto (set) dos índices dos pedaços que este par possui.
        self.pedacos_sendo_baixados = set()     # Conjunto dos pedaços que estão em processo de download.
        self.lock_pedacos = threading.Lock()    # Lock para garantir acesso seguro às listas de pedaços entre threads.

        # --- Controle dinâmico de downloads ---
        self.max_downloads_atual = BASE_DOWNLOADS_SIMULTANEOS # Limite atual de downloads simultâneos, que será ajustado.
        self.executor_downloads = None         # Pool de threads para gerenciar os downloads.
        self.lock_executor = threading.Lock()  # Lock para proteger a recriação do pool de threads.

        if self.eh_semeador_inicial:
            # Se for um semeador inicial, ele possui todos os pedaços desde o começo.
            self.meus_pedacos = set(range(TOTAL_PEDACOS))
            print(f"Par {self.id_par} iniciado como SEMEADOR. Possui todos os {TOTAL_PEDACOS} pedaços.")
        else:
            # Se for um leecher (receptor), cria um arquivo vazio do tamanho final.
            # Isso pré-aloca o espaço em disco para receber os pedaços.
            caminho_arquivo_destino = self.id_par.replace(":", "_") + "_" + NOME_ARQUIVO
            if not os.path.exists(caminho_arquivo_destino):
                with open(caminho_arquivo_destino, 'wb') as f:
                    f.truncate(TAMANHO_ARQUIVO_MB * 1024 * 1024)

        self._atualizar_thread_pool() # Inicializa o pool de threads com a capacidade base.

        # --- Inicia as threads principais do Par ---
        # Thread para atuar como servidor, atendendo requisições de outros pares.
        thread_servidor = threading.Thread(target=self.executar_servidor)
        thread_servidor.daemon = True # Permite que o programa finalize mesmo que a thread esteja rodando.
        thread_servidor.start()

        # Thread para atuar como cliente, gerenciando o download de pedaços.
        thread_download = threading.Thread(target=self.iniciar_download)
        thread_download.daemon = True
        thread_download.start()

    def _atualizar_thread_pool(self):
        """Recria o pool de threads com o novo número máximo de workers (downloads simultâneos)."""
        with self.lock_executor:
            if self.executor_downloads:
                self.executor_downloads.shutdown(wait=False) # Encerra o pool antigo sem esperar as tarefas.
            self.executor_downloads = ThreadPoolExecutor(max_workers=self.max_downloads_atual)

    def calcular_downloads_otimos(self, info_todos_pares):
        """
        Calcula dinamicamente o número ideal de downloads simultâneos com base na saúde da rede.
        A lógica aumenta a agressividade do download conforme mais cópias do arquivo (seeds)
        e mais pares (peers) estão disponíveis.
        """
        if not info_todos_pares:
            return BASE_DOWNLOADS_SIMULTANEOS

        total_seeds = 0
        total_peers = 0

        # Conta quantos seeds e peers estão na rede.
        for id_par, pedacos in info_todos_pares.items():
            if id_par != self.id_par:  # Ignora a si mesmo na contagem.
                if len(pedacos) == TOTAL_PEDACOS:
                    total_seeds += 1
                else:
                    total_peers += 1
        
        # Aplica a fórmula para determinar o número de downloads.
        downloads_otimos = (BASE_DOWNLOADS_SIMULTANEOS +
                              (total_seeds * INCREMENTO_POR_SEED) +
                              (total_peers * INCREMENTO_POR_PEER))
        
        # Limita o valor a um máximo de 100 para não sobrecarregar o sistema.
        downloads_otimos = min(downloads_otimos, 100)
        
        # Exibe um log da análise de rede para depuração.
        print(f"*** ANÁLISE DE REDE ***")
        print(f"Seeds disponíveis: {total_seeds}")
        print(f"Peers disponíveis: {total_peers}")
        print(f"Downloads simultâneos calculados: {downloads_otimos}")
        
        return downloads_otimos

    def executar_servidor(self):
        """
        Inicia o lado servidor do par, que fica escutando por conexões de outros pares
        que desejam baixar pedaços.
        """
        socket_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        socket_servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) # Permite reutilizar o endereço.
        socket_servidor.bind((self.host_servidor, self.porta_servidor))
        socket_servidor.listen(MAX_CONEXOES_SERVIDOR)
        print(f"Servidor do Par {self.id_par} escutando em {self.host_servidor}:{self.porta_servidor}")
        
        # Usa um pool de threads para lidar com múltiplas requisições de upload simultaneamente.
        executor_servidor = ThreadPoolExecutor(max_workers=MAX_CONEXOES_SERVIDOR)
        
        while True:
            try:
                socket_cliente, endereco = socket_servidor.accept() # Aceita uma nova conexão.
                executor_servidor.submit(self.lidar_com_requisicao, socket_cliente) # Delega para uma thread.
            except Exception as e:
                print(f"Erro ao aceitar conexão: {e}")

    def lidar_com_requisicao(self, socket_cliente):
        """
        Processa uma requisição de um outro par para um pedaço específico.
        """
        try:
            socket_cliente.settimeout(TIMEOUT_CONEXAO)
            requisicao = socket_cliente.recv(1024).decode() # Lê a requisição (ex: "GET 123").
            if requisicao.startswith("GET"):
                indice_pedaco = int(requisicao.split(" ")[1])
                
                with self.lock_pedacos:
                    if indice_pedaco in self.meus_pedacos:
                        # Determina o nome do arquivo de origem.
                        arquivo_origem = NOME_ARQUIVO if self.eh_semeador_inicial else self.id_par.replace(":", "_") + "_" + NOME_ARQUIVO
                        
                        # Lê o pedaço do arquivo local e o envia pela rede.
                        with open(arquivo_origem, 'rb') as f:
                            f.seek(indice_pedaco * TAMANHO_PEDACO) # Vai para a posição correta no arquivo.
                            dados = f.read(TAMANHO_PEDACO)
                            
                            bytes_enviados = 0
                            while bytes_enviados < len(dados):
                                chunk = dados[bytes_enviados:bytes_enviados + BUFFER_SIZE]
                                socket_cliente.sendall(chunk)
                                bytes_enviados += len(chunk)

                        print(f"Par {self.id_par}: Enviou o pedaço {indice_pedaco} para outro par.")
                    else:
                        # Se não possui o pedaço, informa o erro.
                        socket_cliente.sendall(b"ERRO: Pedaco nao encontrado")
        except Exception as e:
            print(f"Erro ao lidar com requisição: {e}")
        finally:
            try:
                socket_cliente.close() # Garante que a conexão seja fechada.
            except:
                pass

    def iniciar_download(self):
        """
        Gerencia todo o processo de download. É o loop principal do cliente.
        """
        if self.eh_semeador_inicial:
            # Se for um semeador, apenas se registra no rastreador e espera por conexões.
            print(f"*** Par {self.id_par}: Atuando como semeador inicial. Aguardando conexões. ***")
            self.rastreador.registrar(self.id_par, list(self.meus_pedacos))
            return

        downloads_ativos = [] # Lista para rastrear as tarefas de download em andamento.
        ultima_atualizacao_pool = 0
        
        # Loop principal: continua enquanto não tiver baixado todos os pedaços.
        while len(self.meus_pedacos) < TOTAL_PEDACOS:
            print(f"\n--- Status Par {self.id_par} ---")
            print(f"Progresso: {len(self.meus_pedacos)} / {TOTAL_PEDACOS} pedaços ({(len(self.meus_pedacos)/TOTAL_PEDACOS)*100:.2f}%)")
            
            # Atualiza o rastreador com os pedaços que já possui.
            with self.lock_pedacos:
                self.rastreador.registrar(self.id_par, list(self.meus_pedacos))
            
            # Obtém a lista de todos os pares e seus respectivos pedaços do rastreador.
            info_todos_pares = self.rastreador.obter_pares()
            
            # Lógica adaptativa: recalcula o número de downloads ótimos periodicamente.
            tempo_atual = time.time()
            if tempo_atual - ultima_atualizacao_pool > 5: # Recalcula a cada 5 segundos.
                downloads_otimos = self.calcular_downloads_otimos(info_todos_pares)
                
                if downloads_otimos != self.max_downloads_atual:
                    print(f"*** ADAPTAÇÃO DINÂMICA: Mudando de {self.max_downloads_atual} para {downloads_otimos} downloads simultâneos ***")
                    self.max_downloads_atual = downloads_otimos
                    self._atualizar_thread_pool() # Redimensiona o pool de threads.
                
                ultima_atualizacao_pool = tempo_atual
            
            # Obtém uma lista de todos os pedaços que pode baixar, ordenados por raridade.
            pedacos_disponiveis = self.obter_todos_pedacos_disponiveis(info_todos_pares)
            
            # Calcula quantos novos downloads pode iniciar.
            downloads_que_podem_ser_iniciados = self.max_downloads_atual - len(downloads_ativos)
            
            if downloads_que_podem_ser_iniciados > 0 and pedacos_disponiveis:
                # Pega os pedaços mais raros para iniciar os downloads.
                downloads_para_iniciar = pedacos_disponiveis[:downloads_que_podem_ser_iniciados]
                
                for pedaco, pares_disponiveis in downloads_para_iniciar:
                    # Prioriza baixar de seeds (mais confiáveis e rápidos) em vez de peers.
                    seeds = [p for p in pares_disponiveis if len(info_todos_pares.get(p, [])) == TOTAL_PEDACOS]
                    peers = [p for p in pares_disponiveis if p not in seeds]
                    
                    if seeds:
                        par_escolhido = random.choice(seeds)
                    elif peers:
                        par_escolhido = random.choice(peers)
                    else:
                        continue # Nenhum par disponível para este pedaço.
                        
                    host, porta = par_escolhido.split(":")
                    
                    # Marca o pedaço como "sendo baixado" para não tentar baixá-lo novamente.
                    with self.lock_pedacos:
                        self.pedacos_sendo_baixados.add(pedaco)
                    
                    # Submete a tarefa de download ao pool de threads.
                    future = self.executor_downloads.submit(
                        self.requisitar_pedaco_do_par, host, int(porta), pedaco
                    )
                    downloads_ativos.append((future, pedaco))
                    print(f"Iniciando download do pedaço {pedaco} de {par_escolhido}")

            # Verifica quais downloads da lista de ativos já foram concluídos.
            downloads_concluidos = []
            for future, pedaco in downloads_ativos:
                if future.done():
                    downloads_concluidos.append((future, pedaco))
                    try:
                        sucesso = future.result()
                        # Se o download falhou, libera o pedaço para ser tentado novamente.
                        if not sucesso:
                            with self.lock_pedacos:
                                self.pedacos_sendo_baixados.discard(pedaco)
                    except Exception as e:
                        print(f"Erro no download do pedaço {pedaco}: {e}")
                        with self.lock_pedacos:
                            self.pedacos_sendo_baixados.discard(pedaco)
            
            # Remove os downloads concluídos (com sucesso ou falha) da lista de ativos.
            for item in downloads_concluidos:
                downloads_ativos.remove(item)
            
            time.sleep(INTERVALO_ATUALIZACAO)
        
        print(f"\n*** Par {self.id_par}: DOWNLOAD COMPLETO! ***")
        self.rastreador.registrar(self.id_par, list(self.meus_pedacos))
        
        # Após completar, o par se mantém ativo na rede como um seeder.
        while True:
            time.sleep(60)

    def obter_todos_pedacos_disponiveis(self, info_todos_pares):
        """
        Analisa a informação de todos os pares para descobrir quais pedaços estão disponíveis
        para download. Implementa a estratégia "rarest first" (o mais raro primeiro),
        priorizando os pedaços que menos pares possuem.
        """
        contagem_pedacos = defaultdict(list)
        
        # Mapeia cada pedaço para a lista de pares que o possuem.
        for id_par, pedacos in info_todos_pares.items():
            if id_par != self.id_par:
                for pedaco in pedacos:
                    with self.lock_pedacos:
                        # Considera apenas pedaços que este par não tem e não está baixando.
                        if pedaco not in self.meus_pedacos and pedaco not in self.pedacos_sendo_baixados:
                            contagem_pedacos[pedaco].append(id_par)
        
        if not contagem_pedacos:
            return []
        
        # Ordena os pedaços: primeiro pelo número de pares que o possuem (raridade),
        # depois pelo índice do pedaço como critério de desempate.
        pedacos_ordenados = sorted(
            contagem_pedacos.items(), 
            key=lambda item: (len(item[1]), item[0])
        )
        
        return pedacos_ordenados

    def requisitar_pedaco_do_par(self, host, porta, indice_pedaco):
        """
        Conecta-se a outro par e tenta baixar um único pedaço.
        Retorna True em caso de sucesso, False em caso de falha.
        """
        try:
            print(f"Par {self.id_par}: Tentando baixar pedaço {indice_pedaco} de {host}:{porta}")
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(TIMEOUT_CONEXAO)
                s.connect((host, porta))
                s.sendall(f"GET {indice_pedaco}".encode()) # Envia a requisição.
                
                dados = b''
                # Loop para receber os dados do pedaço.
                while len(dados) < TAMANHO_PEDACO:
                    try:
                        pacote = s.recv(min(BUFFER_SIZE, TAMANHO_PEDACO - len(dados)))
                        if not pacote:
                            break # Conexão fechada pelo outro lado.
                        dados += pacote
                    except socket.timeout:
                        print(f"Timeout ao receber dados do pedaço {indice_pedaco} de {host}:{porta}")
                        break
                
                # Verifica se o pedaço foi recebido completamente.
                if len(dados) == TAMANHO_PEDACO:
                    self.salvar_pedaco(indice_pedaco, dados)
                    return True
                else:
                    print(f"Erro: Recebidos dados incompletos para o pedaço {indice_pedaco} ({len(dados)}/{TAMANHO_PEDACO} bytes)")
                    return False
        except Exception as e:
            print(f"Falha ao conectar com {host}:{porta} para pegar o pedaço {indice_pedaco}: {e}")
            return False
        finally:
            # Garante que o pedaço seja removido da lista de "sendo baixados", independentemente do resultado.
            with self.lock_pedacos:
                self.pedacos_sendo_baixados.discard(indice_pedaco)

    def salvar_pedaco(self, indice_pedaco, dados):
        """
        Escreve os dados de um pedaço baixado no arquivo local, na posição correta.
        """
        caminho_arquivo = self.id_par.replace(":", "_") + "_" + NOME_ARQUIVO
        
        with self.lock_pedacos:
            # Abre o arquivo em modo de leitura e escrita binária ('r+b').
            with open(caminho_arquivo, 'r+b') as f:
                f.seek(indice_pedaco * TAMANHO_PEDACO) # Move o cursor para a posição correta.
                f.write(dados) # Escreve os dados.
            
            # Adiciona o índice à lista de pedaços possuídos.
            self.meus_pedacos.add(indice_pedaco)
            self.pedacos_sendo_baixados.discard(indice_pedaco)
        
        print(f"Par {self.id_par}: Pedaço {indice_pedaco} salvo. Total: {len(self.meus_pedacos)}")

    def __del__(self):
        """Destrutor para limpar recursos, como fechar o pool de threads."""
        with self.lock_executor:
            if self.executor_downloads:
                self.executor_downloads.shutdown(wait=True)

# --- Ponto de Entrada do Programa ---
if __name__ == "__main__":
    import sys
    # Valida os argumentos da linha de comando.
    if len(sys.argv) != 4:
        print("Uso: python par.py <host> <porta> <semeador (true/false)>")
        sys.exit(1)
        
    # Extrai os argumentos.
    host = sys.argv[1]
    porta = int(sys.argv[2])
    eh_semeador = sys.argv[3].lower() == 'true'
    
    # Cria a instância do Par, que inicia todo o processo.
    par = Par(host, porta, eh_semeador)
    
    try:
        # Mantém o programa principal rodando indefinidamente.
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        # Permite encerrar o par de forma limpa com Ctrl+C.
        print("Encerrando o par...")