﻿# --- Importações de bibliotecas necessárias ---
import os # O módulo 'os' fornece uma maneira de usar funcionalidades dependentes do sistema operacional, como interagir com o sistema de arquivos.

def criar_arquivo_teste(nome_arquivo, tamanho_mb):
    """
    Cria um arquivo de teste com um tamanho específico, preenchido com bytes nulos.
    Este script é um utilitário para gerar o arquivo inicial que será compartilhado pelo
    primeiro semeador (seeder) na rede P2P.
    
    :param nome_arquivo: O nome do arquivo a ser criado (ex: "ubuntu-teste.iso").
    :param tamanho_mb: O tamanho desejado para o arquivo em Megabytes (MB).
    """
    # Calcula o tamanho total do arquivo em bytes.
    tamanho_bytes = tamanho_mb * 1024 * 1024

    # Verifica se o arquivo já existe no diretório atual para evitar recriá-lo desnecessariamente.
    if os.path.exists(nome_arquivo):
        print(f"O arquivo '{nome_arquivo}' já existe. Nenhuma ação necessária.")
        # Interrompe a execução da função se o arquivo já existir.
        return
        
    print(f"Criando o arquivo de teste '{nome_arquivo}' com {tamanho_mb} MB...")
    
    # Abre o arquivo no modo de escrita binária ('wb').
    # O 'with' garante que o arquivo seja fechado corretamente no final, mesmo se ocorrer um erro.
    with open(nome_arquivo, 'wb') as f:
        # Para criar arquivos grandes de forma eficiente, escrevemos os dados em blocos.
        # Em vez de escrever byte por byte, escrevemos um bloco de 1MB de cada vez.
        tamanho_bloco = 1024 * 1024  # 1 MB
        numero_blocos = tamanho_mb   # O número de blocos de 1MB é igual ao tamanho em MB.
        
        # Loop que se repete 'numero_blocos' vezes.
        for _ in range(numero_blocos):
            # Escreve um bloco de 1MB contendo apenas bytes nulos (b'\0').
            f.write(b'\0' * tamanho_bloco)
            
    print("Arquivo de teste criado com sucesso!")

# --- Ponto de Entrada do Programa ---
# O bloco de código abaixo só será executado se este script for rodado diretamente.
if __name__ == "__main__":
    # Define as configurações do arquivo a ser criado.
    # Estes valores devem ser os mesmos definidos no cliente P2P (par.py).
    NOME_ARQUIVO = "ubuntu-teste.iso"
    TAMANHO_ARQUIVO_MB = 500
    
    # Chama a função para criar o arquivo com as configurações especificadas.
    criar_arquivo_teste(NOME_ARQUIVO, TAMANHO_ARQUIVO_MB)