﻿# --- Importações de bibliotecas necessárias ---
from xmlrpc.server import SimpleXMLRPCServer # Para criar um servidor RPC (Remote Procedure Call) simples.
import threading                           # Para garantir que o acesso aos dados seja seguro em um ambiente com múltiplas threads.

class Rastreador:
    """
    Representa o servidor rastreador (tracker) da rede P2P.
    Sua função é centralizar as informações sobre quais pares (peers) estão na rede
    e quais pedaços de arquivo cada par possui. Ele não armazena o arquivo,
    apenas coordena a comunicação entre os pares.
    """
    def __init__(self):
        # Dicionário para armazenar o estado da rede.
        # A chave é o ID do par (ex: "localhost:9001") e o valor é uma lista dos índices dos pedaços que ele possui.
        self._pares = {}
        # Um "lock" (trava) é essencial para evitar condições de corrida. Como múltiplos pares podem
        # registrar-se ao mesmo tempo, a trava garante que apenas uma operação de escrita ou leitura
        # seja feita por vez no dicionário _pares, mantendo a integridade dos dados.
        self._trava = threading.Lock()

    def registrar(self, id_par, pedacos):
        """
        Método exposto via RPC para que um par se registre ou atualize seu status no rastreador.
        
        :param id_par: O identificador único do par (ex: "host:porta").
        :param pedacos: Uma lista contendo os índices dos pedaços que o par possui.
        :return: True para confirmar o registro.
        """
        # A instrução 'with self._trava:' adquire a trava antes de executar o bloco
        # e a libera automaticamente ao final, mesmo que ocorram erros.
        with self._trava:
            self._pares[id_par] = pedacos
            print(f"\n[REGISTRO] Par '{id_par}' atualizou seu status com {len(pedacos)} pedaços.")
            print(f"[INFO] Total de pares ativos na rede: {len(self._pares)}")
        return True

    def obter_pares(self):
        """
        Método exposto via RPC que retorna a lista completa de pares e os pedaços que cada um possui.
        Os clientes usam esta função para descobrir de quem podem baixar os pedaços que precisam.

        :return: Um dicionário com todos os pares e suas listas de pedaços.
        """
        with self._trava:
            print(f"\n[REQUISIÇÃO] Um par solicitou a lista de todos os {len(self._pares)} pares.")
            # Retorna uma cópia do dicionário para evitar que o cliente modifique o estado interno do rastreador.
            return self._pares.copy()

    def obter_donos_pedaco(self, indice_pedaco):
        """
        Método exposto via RPC para encontrar todos os pares que possuem um pedaço específico.
        
        :param indice_pedaco: O índice do pedaço a ser procurado.
        :return: Uma lista de IDs dos pares que possuem o pedaço.
        """
        with self._trava:
            donos = []
            # Itera sobre todos os pares registrados.
            for id_par, pedacos in self._pares.items():
                # Verifica se o índice do pedaço está na lista de pedaços do par.
                if indice_pedaco in pedacos:
                    donos.append(id_par)
            print(f"\n[BUSCA] Um par buscou pelo pedaço {indice_pedaco}. Encontrados {len(donos)} donos.")
            return donos

def executar_rastreador(host='localhost', porta=8000):
    """
    Configura e inicia o servidor XML-RPC do rastreador.
    """
    # Cria a instância do servidor, especificando o host e a porta onde ele deve escutar.
    # 'allow_none=True' permite que os métodos RPC retornem 'None'.
    servidor = SimpleXMLRPCServer((host, porta), allow_none=True)
    
    # Registra uma instância da classe Rastreador. Isso faz com que os métodos públicos
    # da instância (registrar, obter_pares, etc.) fiquem disponíveis para serem chamados remotamente.
    servidor.register_instance(Rastreador())
    
    print("=======================================")
    print("      Servidor Rastreador Iniciado     ")
    print("=======================================")
    print(f" Escutando em http://{host}:{porta}")
    print(" Pressione Ctrl+C para encerrar.")
    print("=======================================\n")
    
    # Inicia o loop infinito do servidor, que aguardará por conexões e processará as chamadas RPC.
    servidor.serve_forever()

# --- Ponto de Entrada do Programa ---
if __name__ == "__main__":
    # Chama a função para iniciar o servidor do rastreador quando o script é executado diretamente.
    executar_rastreador()
